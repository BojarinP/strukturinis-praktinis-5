#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>
#include <filesystem>

using namespace std;

// ===== STUDENTO STRUKTŪRA =====
struct Student {
    int id;
    string answers;
    int score = 0;
    double percent = 0.0;
    int grade = 1;
};

// ===== BALŲ SKAIČIAVIMAS =====
int calcScore(const string& correct, const string& ans) {
    int s = 0;
    for (int i = 0; i < 20; i++) {
        if (i >= ans.size() || ans[i] == '-' || ans[i] == ' ')
            continue;
        if (ans[i] == correct[i]) s += 2;
        else s -= 1;
    }
    return s;
}

// ===== PAŽYMYS IŠ PROCENTŲ =====
int gradeFromPercent(double p) {
    if (p >= 95) return 10;
    if (p >= 85) return 9;
    if (p >= 75) return 8;
    if (p >= 65) return 7;
    if (p >= 55) return 6;
    if (p >= 50) return 5;
    if (p >= 35) return 4;
    if (p >= 25) return 3;
    if (p >= 15) return 2;
    return 1;
}

// ===== KLASĖS STATISTIKA =====
void classStats(const vector<Student>& s) {
    int n = s.size();
    int minS = s[0].score, maxS = s[0].score;
    double avgS = 0, avgP = 0;
    int grades[11] = {0};

    for (auto& st : s) {
        minS = min(minS, st.score);
        maxS = max(maxS, st.score);
        avgS += st.score;
        avgP += st.percent;
        grades[st.grade]++;
    }

    cout << "\n--- KLASĖS STATISTIKA ---\n";
    cout << "Studentų skaičius: " << n << endl;
    cout << "Min balas: " << minS << endl;
    cout << "Max balas: " << maxS << endl;
    cout << "Vid. balas: " << avgS / n << endl;
    cout << "Vid. procentai: " << avgP / n << "%\n";

    cout << "Pažymių pasiskirstymas:\n";
    for (int i = 1; i <= 10; i++)
        cout << i << ": " << grades[i] << endl;
}

// ===== STUDENTO PAIEŠKA =====
void searchStudent(const vector<Student>& s) {
    int id;
    do {
        cout << "\nĮveskite studento ID (0 – baigti): ";
        cin >> id;
        if (id == 0) break;

        bool found = false;
        for (auto& st : s) {
            if (st.id == id) {
                cout << "ID: " << st.id
                     << " | Taškai: " << st.score
                     << " | %: " << st.percent
                     << " | Pažymys: " << st.grade << endl;
                found = true;
                break;
            }
        }
        if (!found) cout << "Studentas nerastas.\n";
    } while (true);
}

// ===== KLAUSIMŲ STATISTIKA =====
void questionStats(const vector<Student>& s, const string& correct) {
    cout << "\n--- KLAUSIMŲ STATISTIKA ---\n";
    int n = s.size();

    for (int i = 0; i < 20; i++) {
        int t = 0, f = 0, na = 0;
        for (auto& st : s) {
            if (i >= st.answers.size() || st.answers[i] == '-' || st.answers[i] == ' ')
                na++;
            else if (st.answers[i] == correct[i])
                t++;
            else
                f++;
        }
        cout << "Klausimas " << i + 1
             << ": T=" << t << " F=" << f << " N=" << na << endl;
    }
}

// ===== SUNKIAUSIAS KLAUSIMAS =====
void hardestQuestion(const vector<Student>& s, const string& correct) {
    int n = s.size();
    double minP = 101;
    vector<int> hard;

    for (int i = 0; i < 20; i++) {
        int t = 0;
        for (auto& st : s)
            if (i < st.answers.size() && st.answers[i] == correct[i]) t++;

        double p = (double)t / n * 100;
        if (p < minP) {
            minP = p;
            hard.clear();
            hard.push_back(i + 1);
        } else if (p == minP)
            hard.push_back(i + 1);
    }

    cout << "\nSunkiausias klausimas (-ai): ";
    for (int q : hard) cout << q << " ";
    cout << "(" << minP << "% teisingų)\n";
}

// ===== MAIN =====
int main() {
    // SVARBIAUSIA VIETA – VEIKIA DEBUG
    filesystem::path baseDir = filesystem::current_path();
    filesystem::path inputFile = baseDir / "testData.txt";

    ifstream fin(inputFile);
    if (!fin) {
        cout << "Nepavyko atidaryti failo: " << inputFile << endl;
        system("pause");
        return 1;
    }

    string correct;
    getline(fin, correct);

    vector<Student> students;
    Student st;
    while (fin >> st.id >> st.answers) {
        st.score = calcScore(correct, st.answers);
        st.percent = st.score / 40.0 * 100;
        st.grade = gradeFromPercent(st.percent);
        students.push_back(st);
    }
    fin.close();

    ofstream fout(baseDir / "results.txt");
    for (auto& s : students)
        fout << s.id << " " << s.score << " "
             << fixed << setprecision(1) << s.percent
             << " " << s.grade << endl;
    fout.close();

    cout << "\n--- REZULTATAI ---\n";
    for (auto& s : students)
        cout << s.id << " | " << s.score << " | "
             << s.percent << "% | " << s.grade << endl;

    classStats(students);
    questionStats(students, correct);
    hardestQuestion(students, correct);
    searchStudent(students);

    system("pause");
    return 0;
}
